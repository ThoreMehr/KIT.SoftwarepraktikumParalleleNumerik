./matrixmul_lin_N$2_$1_icc m1.mat m2.mat m3.mat
./matrixmul_red_N$2_$1_icc m1.mat m2.mat m3.mat
./matrixmul_in_N$2_$1_icc m1.mat m2.mat m3.mat
./matrixmul_out_N$2_$1_icc m1.mat m2.mat m3.mat
./matrixmul_lin_N$2_$1_gcc m1.mat m2.mat m3.mat
./matrixmul_red_N$2_$1_gcc m1.mat m2.mat m3.mat
./matrixmul_in_N$2_$1_gcc m1.mat m2.mat m3.mat
./matrixmul_out_N$2_$1_gcc m1.mat m2.mat m3.mat
