
#define L 6
#define D ((1 << L) - 1)
#define N (D * D)
#define H (1.0 / (D + 1))
#define EPSILON 1e-6

#define SHOW_RESULTS 0
