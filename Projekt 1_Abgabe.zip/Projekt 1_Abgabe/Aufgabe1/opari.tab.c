#include "pomp_lib.h"


extern struct ompregdescr omp_rd_27;

int POMP_MAX_ID = 28;

struct ompregdescr* pomp_rd_table[28] = {
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  &omp_rd_27,
};
