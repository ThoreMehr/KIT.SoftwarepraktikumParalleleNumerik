
#define L 2
#define D ((1 << L) - 1)
#define N (D * D)
#define EPSILON 1e-6

#define SHOW_RESULTS 1
