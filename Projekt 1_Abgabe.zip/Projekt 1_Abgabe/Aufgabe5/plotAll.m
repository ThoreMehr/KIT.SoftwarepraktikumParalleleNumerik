L2;figure(1);plot
L3;figure(2);plot
L4;figure(3);plot
L5;figure(4);plot
L6;figure(5);plot
L7;figure(6);plot
L8;figure(7);plot